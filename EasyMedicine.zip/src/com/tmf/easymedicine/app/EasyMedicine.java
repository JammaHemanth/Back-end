package com.tmf.easymedicine.app;

import com.tmf.easymedicine.controllers.MedicineController;
import com.tmf.easymedicine.controllers.MedicineControllerImpl;

public class EasyMedicine {
	public static void main(String[] args) {
		MedicineController controller = new MedicineControllerImpl();
		controller.menu();
	}
}
