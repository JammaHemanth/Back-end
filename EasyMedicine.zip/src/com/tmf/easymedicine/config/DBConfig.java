package com.tmf.easymedicine.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConfig {
	private Connection con;
	
	public Connection getConnection() {
		try {
			//Finding Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver found Successfully");
			String uri = "jdbc:mysql://localhost:3306/easymedicine";
			String user = "root";
			String pwd = "root";
			//Connecting with the Database
			con = DriverManager.getConnection(uri,user,pwd);
		} catch (ClassNotFoundException e) {
			System.out.println("Sorry!!! Unable to find the driver");
		} catch (SQLException e) {
			System.out.println("Sorry!!! currently unable to connect to the database");
		}
		return con;
	}
}
