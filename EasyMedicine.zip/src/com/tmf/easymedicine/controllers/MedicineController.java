package com.tmf.easymedicine.controllers;

public interface MedicineController {
	void addMedicine();
	void deleteMedicine();
	void displayAllMedicine();
	void displayMedicineByPurpose(String purpose);
	void displayMedicineById();
	void updateMedicine();
	void menu();
}
