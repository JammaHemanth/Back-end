package com.tmf.easymedicine.controllers;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.tmf.easymedicine.models.Medicine;
import com.tmf.easymedicine.services.MedicineServiceImpl;
import com.tmf.easymedicine.services.MedicineServices;

public class MedicineControllerImpl implements MedicineController{

	//Scanner Object
	private Scanner scan = new Scanner(System.in);
	
	//Services Object
	private MedicineServices service = new MedicineServiceImpl();
	@Override
	public void addMedicine() {
		System.out.println("Enter Medicine ID");
		int id = scan.nextInt();
		System.out.println("Enter Medicine Name");
		String name = scan.next();
		System.out.println("Enter Medicine Purpose");
		String purpose = scan.next();
		System.out.println("Enter Medicine Type");
		String type = scan.next();
		System.out.println("Enter Medicine DOM");
		String man = scan.next();
		Date dom = Date.valueOf(man);
		
		System.out.println("Enter Medicine DOE");
		String exp  = scan.next();
		Date doe = Date.valueOf(exp);
		
		System.out.println("Enter Medicine Price per Unit");
		double ppu = scan.nextDouble();
		double pps = (ppu * 10) * 0.02;
		System.out.println("Enter Medicine Dosage");
		String dosage = scan.next();
		System.out.println("Enter Medicine Description");
		String desc = scan.next();
		System.out.println("Enter Medicine Company Name");
		String cname = scan.next();
		
		
		Medicine med = new Medicine();
		med.setCompanyName(cname);
		med.setDoe(doe);
		med.setDom(dom);
		med.setDosage(dosage);
		med.setDrugDescription(desc);
		med.setMedId(id);
		med.setMedName(name);
		med.setPricePerStrip(pps);
		med.setPurpose(purpose);
		med.setTypeOfMedicine(type);
		med.setPricePerUnit(ppu);
		
		//send the medicine object to the service layer.
		service.addMedicine(med);
		
		System.out.println("Medicine has been loaded");
	}

	@Override
	public void deleteMedicine() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayAllMedicine() {
		List<Medicine> medicines = service.displayAllMedicine();
		medicines.forEach(System.out::println);
	}

	@Override
	public void displayMedicineByPurpose(String purpose) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayMedicineById() {
		// TODO Auto-generated method stub
		System.out.println("Enter the Id of a medicine");
		int id = scan.nextInt();
		
		Medicine med = service.displayMedicineById(id);
		
		System.out.println(med);
	}

	@Override
	public void updateMedicine() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menu() {
		// TODO Auto-generated method stub
		while(true) {
			System.out.println("============================Welcome to Easy Medicine====================");
			System.out.println("\t1. Add new Medicine");
			System.out.println("\t2. Display All Medicine");
			System.out.println("\t3. Display Medicine By Id");
			System.out.println("\t9. Exit");
			
			System.out.println("\n\t Enter your Option");
			int opt = scan.nextInt();
			
			switch(opt) {
			case 1 : addMedicine();break;
			case 2 : displayAllMedicine();break;
			case 3 : displayMedicineById();break;
			case 9 : System.exit(opt);
			default : System.out.println("!!!Sorry... You've entered a wrong choice");
			}
		}
	}
	
}
