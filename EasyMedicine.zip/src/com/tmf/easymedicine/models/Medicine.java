package com.tmf.easymedicine.models;

import java.sql.Date;

public class Medicine {
	int medId;
	String medName,companyName,drugDescription,dosage;
	String typeOfMedicine,purpose;
	double pricePerUnit,pricePerStrip;
	Date dom,doe;
	public int getMedId() {
		return medId;
	}
	public void setMedId(int medId) {
		this.medId = medId;
	}
	public String getMedName() {
		return medName;
	}
	public void setMedName(String medName) {
		this.medName = medName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDrugDescription() {
		return drugDescription;
	}
	public void setDrugDescription(String drugDescription) {
		this.drugDescription = drugDescription;
	}
	public String getDosage() {
		return dosage;
	}
	public void setDosage(String dosage) {
		this.dosage = dosage;
	}
	public String getTypeOfMedicine() {
		return typeOfMedicine;
	}
	public void setTypeOfMedicine(String typeOfMedicine) {
		this.typeOfMedicine = typeOfMedicine;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public double getPricePerStrip() {
		return pricePerStrip;
	}
	public void setPricePerStrip(double pricePerStrip) {
		this.pricePerStrip = pricePerStrip;
	}
	public Date getDom() {
		return dom;
	}
	public void setDom(Date dom) {
		this.dom = dom;
	}
	public Date getDoe() {
		return doe;
	}
	public void setDoe(Date doe) {
		this.doe = doe;
	}
	@Override
	public String toString() {
		return "Medicine [medId=" + medId + ", medName=" + medName + ", companyName=" + companyName
				+ ", drugDescription=" + drugDescription + ", dosage=" + dosage + ", typeOfMedicine=" + typeOfMedicine
				+ ", purpose=" + purpose + ", pricePerUnit=" + pricePerUnit + ", pricePerStrip=" + pricePerStrip
				+ ", dom=" + dom + ", doe=" + doe + "]";
	}
	
}
