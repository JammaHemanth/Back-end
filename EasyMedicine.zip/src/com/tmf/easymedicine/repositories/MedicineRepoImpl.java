package com.tmf.easymedicine.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tmf.easymedicine.config.DBConfig;
import com.tmf.easymedicine.models.Medicine;

public class MedicineRepoImpl implements MedicineRepository{
	//Create a Database Configuration object
	private DBConfig config = new DBConfig();
	
	//Create a Connection object.
	private Connection con = config.getConnection();
	
	private PreparedStatement ps;
	private ResultSet rs;
	private String query;
	
	@Override
	public void addMedicine(Medicine medicine) {
		try {
			query = "insert into Medicine values(?,?,?,?,?,?,?,?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setInt(1, medicine.getMedId());
			ps.setString(2, medicine.getMedName());
			ps.setString(3, medicine.getCompanyName());
			ps.setString(4, medicine.getDrugDescription());
			ps.setString(5, medicine.getDosage());
			ps.setString(6, medicine.getTypeOfMedicine());
			ps.setString(7, medicine.getPurpose());
			ps.setDouble(8, medicine.getPricePerUnit());
			ps.setDouble(9, medicine.getPricePerStrip());
			ps.setDate(10, medicine.getDom());
			ps.setDate(11, medicine.getDoe());
			ps.execute();
			System.out.println("Medicine has been added successfully");
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Unable to insert Data");
		}
	}

	@Override
	public List<Medicine> displayAllMedicine() {
		// TODO Auto-generated method stub
		List<Medicine> medicines = new ArrayList<Medicine>();
		try {
			query = "select * from Medicine";
			ps = con.prepareStatement(query);
			//Execute the query and store the records in ResultSet object
			rs = ps.executeQuery();
			
			//Iterating records
			while(rs.next()) {
				//Create a new object per record
				Medicine med = new Medicine();
				
				//Set all details by getting each columns data of a record
				//for the object
				med.setCompanyName(rs.getString("companyName"));
				med.setDoe(rs.getDate("doe"));
				med.setDom(rs.getDate("dom"));
				med.setDosage(rs.getString("dosage"));
				med.setDrugDescription(rs.getString("drugDescription"));
				med.setMedId(rs.getInt("medId"));
				med.setMedName(rs.getString("medName"));
				med.setPricePerStrip(rs.getDouble("pricePerStrip"));
				med.setPurpose(rs.getString("purpose"));
				med.setTypeOfMedicine(rs.getString("typeOfMedicine"));
				med.setPricePerUnit(rs.getDouble("pricePerUnit"));
				
				//Add the object to the list.
				medicines.add(med);
			}
		}
		catch(Exception e) {
			System.out.println("Sorry!!! Unable to connect with the database now...");
		}
		return medicines;
	}

	@Override
	public Medicine displayMedicineById(int medId) {
		//Create a new object per record
		Medicine med = new Medicine();
		try {
			query = "select * from Medicine where medId=?";
			ps = con.prepareStatement(query);
			ps.setInt(1, medId);
			//Execute the query and store the records in ResultSet object
			rs = ps.executeQuery();
			
			//Iterating records
			if(rs.next()) {
				
				//Set all details by getting each columns data of a record
				//for the object
				med.setCompanyName(rs.getString("companyName"));
				med.setDoe(rs.getDate("doe"));
				med.setDom(rs.getDate("dom"));
				med.setDosage(rs.getString("dosage"));
				med.setDrugDescription(rs.getString("drugDescription"));
				med.setMedId(rs.getInt("medId"));
				med.setMedName(rs.getString("medName"));
				med.setPricePerStrip(rs.getDouble("pricePerStrip"));
				med.setPurpose(rs.getString("purpose"));
				med.setTypeOfMedicine(rs.getString("typeOfMedicine"));
				med.setPricePerUnit(rs.getDouble("pricePerUnit"));
				
			}
		}
		catch(Exception e) {
			System.out.println("Sorry!!! Unable to connect with the database now...");
		}
		return med;
	}

	@Override
	public List<Medicine> displayMedicineByPurpose(String purpose) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		
	}

	
}
