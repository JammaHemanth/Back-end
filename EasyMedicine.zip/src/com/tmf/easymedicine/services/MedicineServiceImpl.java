package com.tmf.easymedicine.services;

import java.util.List;

import com.tmf.easymedicine.models.Medicine;
import com.tmf.easymedicine.repositories.MedicineRepoImpl;
import com.tmf.easymedicine.repositories.MedicineRepository;

public class MedicineServiceImpl implements MedicineServices{
	//Create an object for Repository.
	private MedicineRepository repo = new MedicineRepoImpl();

	@Override
	public void addMedicine(Medicine medicine) {
		repo.addMedicine(medicine);
	}

	@Override
	public List<Medicine> displayAllMedicine() {
		// TODO Auto-generated method stub
		return repo.displayAllMedicine();
	}

	@Override
	public Medicine displayMedicineById(int medId) {
		// TODO Auto-generated method stub
		return repo.displayMedicineById(medId);
	}

	@Override
	public List<Medicine> displayMedicineByPurpose(String purpose) {
		// TODO Auto-generated method stub
		return repo.displayMedicineByPurpose(purpose);
	}

	@Override
	public void updateMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		repo.updateMedicine(medicine);
	}

	@Override
	public void deleteMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		repo.deleteMedicine(medicine);
	}
}
