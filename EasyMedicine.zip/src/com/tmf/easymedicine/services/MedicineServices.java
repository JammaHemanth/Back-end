package com.tmf.easymedicine.services;

import java.util.List;

import com.tmf.easymedicine.models.Medicine;

public interface MedicineServices {
	public void addMedicine(Medicine medicine);
	public List<Medicine> displayAllMedicine();
	public Medicine displayMedicineById(int medId);
	public List<Medicine> displayMedicineByPurpose(String purpose);
	public void updateMedicine(Medicine medicine);
	public void deleteMedicine(Medicine medicine);
}
